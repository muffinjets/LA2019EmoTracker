# Item Tracker for Link's Awakening Remake Randomizer

The randomizer got an alpha release the other day, thought I'd add a cobbled together item tracker pack for it.

I'll add a map and locations to it when the randomizer gets later updates!
